import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Lock, ShieldAlert, KeyRound, ArrowRight, Home } from 'lucide-react';
import { dataService } from '../../lib/dataService';
import { cinematicAudio } from '../../lib/audioFX';

interface AdminLoginProps {
  onSuccess: () => void;
  onExit: () => void;
}

export const AdminLogin: React.FC<AdminLoginProps> = ({ onSuccess, onExit }) => {
  const [passcode, setPasscode] = useState('');
  const [error, setError] = useState('');

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (dataService.loginAdmin(passcode)) {
      cinematicAudio.playBassBoom();
      onSuccess();
    } else {
      cinematicAudio.playWhoosh();
      setError('Invalid authorization key. Hint: use default "cinematic2025" or "gokulavasan"');
    }
  };

  return (
    <div className="min-h-screen bg-[#050505] flex items-center justify-center p-4 relative overflow-hidden">
      {/* Background glow */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-96 h-96 bg-[#B50016]/20 rounded-full blur-[140px] pointer-events-none" />

      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        className="relative z-10 w-full max-w-md p-8 rounded-2xl bg-zinc-950 border border-red-950 shadow-glow-red"
      >
        <div className="flex items-center justify-between mb-6">
          <div className="w-12 h-12 rounded-xl bg-red-950/60 border border-[#FF2020]/40 flex items-center justify-center text-[#FF5A00]">
            <Lock className="w-6 h-6" />
          </div>
          <button
            onClick={onExit}
            className="flex items-center gap-1 text-xs font-mono text-zinc-400 hover:text-white"
          >
            <Home className="w-3.5 h-3.5" />
            <span>Return to Portfolio</span>
          </button>
        </div>

        <h2 className="font-cinematic text-2xl font-black uppercase tracking-wider text-white">
          CREATOR CONTROL ROOM
        </h2>
        <p className="text-xs text-zinc-400 mt-1">
          Authorized access to manage Gokulavasan's cinematic projects, media files & site configuration.
        </p>

        {error && (
          <div className="mt-4 p-3 rounded-lg bg-red-950/60 border border-red-800 text-xs text-red-300 flex items-start gap-2">
            <ShieldAlert className="w-4 h-4 text-[#FF2020] shrink-0 mt-0.5" />
            <span>{error}</span>
          </div>
        )}

        <form onSubmit={handleLogin} className="mt-6 space-y-4">
          <div>
            <label className="block text-xs font-mono uppercase tracking-wider text-zinc-400 mb-1.5">
              Admin Passcode / Master Key
            </label>
            <div className="relative">
              <input
                type="password"
                required
                autoFocus
                value={passcode}
                onChange={(e) => {
                  setPasscode(e.target.value);
                  setError('');
                }}
                placeholder="Enter master key..."
                className="w-full px-4 py-3 rounded-lg bg-zinc-900 border border-zinc-800 focus:border-[#FF2020] focus:outline-none text-white text-sm pl-10"
              />
              <KeyRound className="w-4 h-4 text-zinc-500 absolute left-3.5 top-3.5" />
            </div>
          </div>

          <button
            type="submit"
            className="w-full py-3.5 rounded-lg bg-gradient-to-r from-[#B50016] to-[#FF5A00] text-white font-bold text-xs uppercase tracking-widest shadow-glow-red hover:brightness-110 active:scale-95 transition-all flex items-center justify-center gap-2"
          >
            <span>UNLOCK DASHBOARD</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </form>

        <div className="mt-6 pt-4 border-t border-zinc-900 text-center text-[11px] text-zinc-500 font-mono">
          DEFAULT ACCESS KEY: <strong className="text-[#FF9B24]">cinematic2025</strong>
        </div>
      </motion.div>
    </div>
  );
};
