import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Sliders, Layers, Volume2, Sparkles, Scissors, Clock } from 'lucide-react';
import { cinematicAudio } from '../lib/audioFX';

export const VideoEditingShowcase: React.FC = () => {
  const [sliderPos, setSliderPos] = useState(50);

  const editFeatures = [
    {
      title: "Narrative Rhythm & Pacing",
      desc: "Cutting on action, match cuts, and emotional beats that keep viewer retention at peak levels.",
      icon: Scissors
    },
    {
      title: "Audio & Beat Synchronization",
      desc: "Frame-accurate audio transients alignment, punchy SFX layering, and cinematic music scoring.",
      icon: Volume2
    },
    {
      title: "DaVinci Resolve Color Harmonization",
      desc: "Balancing color science across multi-camera setups, skin-tone isolation, and cinematic film LUTs.",
      icon: Sparkles
    },
    {
      title: "Dynamic Titles & Motion Graphics",
      desc: "After Effects lower thirds, typography kinetic animation, and Tamil cinema title sequence design.",
      icon: Layers
    }
  ];

  return (
    <section id="editing" className="relative py-28 bg-[#050505] text-white overflow-hidden border-t border-zinc-900">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <motion.div
            initial={{ opacity: 0, y: 15 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-zinc-900 border border-red-900/40 text-xs uppercase font-bold tracking-[0.25em] text-[#FF5A00] mb-4"
          >
            <Scissors className="w-3.5 h-3.5 text-[#FF2020]" />
            <span>05. EDIT SUITE & POST-PRODUCTION</span>
          </motion.div>

          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="font-cinematic text-3xl sm:text-5xl font-black uppercase tracking-[0.1em] text-white"
          >
            THE ART OF THE CUT
          </motion.h2>

          <motion.p
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            className="mt-4 text-sm sm:text-base font-light tracking-widest text-zinc-400 uppercase"
          >
            WHERE RAW SHOTS TRANSFORM INTO POWERFUL EMOTIONS
          </motion.p>
        </div>

        {/* Interactive Before & After Color Grading Showcase */}
        <div className="mb-16">
          <div className="text-center mb-6">
            <h3 className="text-sm font-mono uppercase tracking-[0.2em] text-[#FF9B24] font-bold">
              INTERACTIVE COLOR GRADING COMPARISON (SLIDE TO REVEAL)
            </h3>
            <p className="text-xs text-zinc-400 mt-1">
              Log Flat Profile (RAW) vs. Cinematic Red-Warm Master Grade
            </p>
          </div>

          <div className="relative mx-auto max-w-4xl aspect-video rounded-2xl overflow-hidden border border-red-900/60 shadow-glow-red select-none">
            {/* Graded Frame (Background) */}
            <img
              src="https://images.unsplash.com/photo-1492691527719-9d1e07e534b4?auto=format&fit=crop&w=1200&q=80"
              alt="Graded Master Cut"
              className="absolute inset-0 w-full h-full object-cover filter contrast-125 saturate-125 hue-rotate-[-10deg]"
            />
            <div className="absolute top-4 right-4 bg-black/80 px-3 py-1 rounded text-[11px] font-mono text-[#FF5A00] font-bold border border-[#FF5A00]/40">
              CINEMATIC MASTER GRADE
            </div>

            {/* RAW Flat Profile (Clipped Overlay) */}
            <div
              className="absolute inset-0 overflow-hidden"
              style={{ width: `${sliderPos}%` }}
            >
              <img
                src="https://images.unsplash.com/photo-1492691527719-9d1e07e534b4?auto=format&fit=crop&w=1200&q=80"
                alt="RAW Flat Cut"
                className="absolute inset-0 w-full h-full object-cover filter grayscale contrast-75 brightness-110"
                style={{ width: '100%', maxWidth: 'none' }}
              />
              <div className="absolute top-4 left-4 bg-black/80 px-3 py-1 rounded text-[11px] font-mono text-zinc-300 font-bold border border-zinc-700">
                RAW / S-LOG FLAT
              </div>
            </div>

            {/* Slider Handle Divider */}
            <div
              className="absolute top-0 bottom-0 w-1 bg-white cursor-ew-resize flex items-center justify-center shadow-[0_0_15px_#FF2020]"
              style={{ left: `${sliderPos}%` }}
            >
              <div className="w-8 h-8 rounded-full bg-[#FF2020] border-2 border-white flex items-center justify-center shadow-lg -ml-3.5">
                <Sliders className="w-4 h-4 text-white rotate-90" />
              </div>
            </div>

            {/* Interactive Slider Input */}
            <input
              type="range"
              min="0"
              max="100"
              value={sliderPos}
              onChange={(e) => {
                setSliderPos(Number(e.target.value));
                if (Math.abs(sliderPos - 50) % 20 === 0) {
                  cinematicAudio.playWhoosh();
                }
              }}
              className="absolute inset-0 w-full h-full opacity-0 cursor-ew-resize z-20"
            />
          </div>
        </div>

        {/* Post-Production Workflow Pillars */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {editFeatures.map((feat, idx) => (
            <motion.div
              key={feat.title}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: idx * 0.1 }}
              className="p-6 rounded-xl bg-zinc-950 border border-zinc-800/80 hover:border-[#FF5A00]/50 transition-all flex flex-col justify-between"
            >
              <div>
                <div className="w-10 h-10 rounded-lg bg-red-950/40 border border-red-800/40 flex items-center justify-center text-[#FF5A00] mb-4">
                  <feat.icon className="w-5 h-5" />
                </div>
                <h4 className="font-cinematic text-base font-bold uppercase tracking-wider text-white">
                  {feat.title}
                </h4>
                <p className="text-xs text-zinc-400 mt-2 leading-relaxed">
                  {feat.desc}
                </p>
              </div>

              <div className="mt-5 pt-3 border-t border-zinc-900 flex items-center justify-between text-[10px] font-mono text-zinc-500">
                <span>PIPELINE: PRO CUT</span>
                <span className="text-[#FF2020]">24 FPS LOCKED</span>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};
