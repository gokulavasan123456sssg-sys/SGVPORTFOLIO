import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { FileDown, Eye, X, CheckCircle, Award, Briefcase, GraduationCap, Printer } from 'lucide-react';
import { ProfileData, ExperienceItem, EducationItem } from '../types';
import { cinematicAudio } from '../lib/audioFX';

interface ResumeSectionProps {
  profile: ProfileData;
  experience: ExperienceItem[];
  education: EducationItem[];
}

export const ResumeSection: React.FC<ResumeSectionProps> = ({ profile, experience, education }) => {
  const [showViewer, setShowViewer] = useState(false);

  const handleDownload = () => {
    cinematicAudio.playWhoosh();
    // Create downloadable resume document or trigger download
    const link = document.createElement('a');
    link.href = profile.resumeUrl || '/Gokulavasan_Resume.pdf';
    link.download = profile.resumeFileName || 'Gokulavasan_Resume.pdf';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleView = () => {
    cinematicAudio.playWhoosh();
    setShowViewer(true);
  };

  return (
    <section id="resume" className="relative py-28 bg-[#050505] text-white overflow-hidden border-t border-zinc-900">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="relative rounded-3xl overflow-hidden bg-gradient-to-r from-red-950/60 via-zinc-950 to-black border border-red-900/60 p-8 sm:p-12 lg:p-16 shadow-glow-red">
          {/* Subtle Watermark */}
          <div className="absolute right-6 -bottom-10 font-cinematic text-8xl sm:text-9xl font-black text-white/[0.03] select-none pointer-events-none">
            CURRICULUM
          </div>

          <div className="max-w-3xl">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-zinc-900 border border-red-900/40 text-xs uppercase font-bold tracking-[0.2em] text-[#FF5A00] mb-4">
              <Award className="w-3.5 h-3.5 text-[#FF2020]" />
              <span>11. OFFICIAL DOSSIER</span>
            </div>

            <h2 className="font-cinematic text-3xl sm:text-5xl font-black uppercase tracking-[0.08em] text-white">
              PROFESSIONAL RESUME
            </h2>

            <p className="mt-4 text-sm sm:text-base text-zinc-300 leading-relaxed">
              Complete documentation of professional experience, video editing workflows, cinematography projects, academic certifications, and creative accomplishments.
            </p>

            {/* Quick Resume Key Metrics */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mt-8 py-6 border-y border-zinc-800">
              <div>
                <span className="block text-[10px] font-mono uppercase text-zinc-400">Current Role</span>
                <span className="text-sm font-bold text-white">Video Editor & DP</span>
              </div>
              <div>
                <span className="block text-[10px] font-mono uppercase text-zinc-400">Production</span>
                <span className="text-sm font-bold text-[#FF9B24]">Koyaka Channel</span>
              </div>
              <div>
                <span className="block text-[10px] font-mono uppercase text-zinc-400">Degree</span>
                <span className="text-sm font-bold text-white">B.E. Cyber Security</span>
              </div>
              <div>
                <span className="block text-[10px] font-mono uppercase text-zinc-400">Specialization</span>
                <span className="text-sm font-bold text-[#FF2020]">VFX & Compositing</span>
              </div>
            </div>

            {/* Actions */}
            <div className="mt-8 flex flex-wrap items-center gap-4">
              <button
                onClick={handleDownload}
                className="px-8 py-4 rounded-xl bg-gradient-to-r from-[#B50016] via-[#FF2020] to-[#FF5A00] text-white font-bold text-xs sm:text-sm uppercase tracking-[0.2em] shadow-glow-red hover:shadow-[0_0_35px_rgba(255,32,32,0.6)] active:scale-95 transition-all duration-300 flex items-center gap-3"
              >
                <FileDown className="w-4 h-4" />
                <span>DOWNLOAD MY RESUME</span>
              </button>

              <button
                onClick={handleView}
                className="px-6 py-4 rounded-xl bg-zinc-900 border border-zinc-700 text-zinc-200 hover:text-white hover:border-[#FF9B24] font-bold text-xs sm:text-sm uppercase tracking-[0.2em] active:scale-95 transition-all duration-300 flex items-center gap-2.5"
              >
                <Eye className="w-4 h-4 text-[#FF9B24]" />
                <span>VIEW RESUME ONLINE</span>
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* RESUME VIEWER MODAL */}
      <AnimatePresence>
        {showViewer && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 bg-black/95 backdrop-blur-xl flex items-center justify-center p-4 sm:p-6"
            onClick={() => setShowViewer(false)}
          >
            <motion.div
              initial={{ scale: 0.9, y: 20 }}
              animate={{ scale: 1, y: 0 }}
              exit={{ scale: 0.9, y: 20 }}
              className="relative w-full max-w-4xl max-h-[90vh] bg-zinc-950 border border-zinc-800 rounded-2xl overflow-hidden shadow-2xl flex flex-col"
              onClick={(e) => e.stopPropagation()}
            >
              {/* Header */}
              <div className="p-4 sm:p-5 border-b border-zinc-800 flex items-center justify-between bg-zinc-900/80">
                <div className="flex items-center gap-3">
                  <div className="p-1.5 rounded bg-[#FF2020]/20 text-[#FF5A00]">
                    <Award className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="font-cinematic text-lg font-bold text-white uppercase tracking-wider">
                      {profile.name} — OFFICIAL RESUME
                    </h3>
                    <span className="text-xs text-zinc-400">
                      Video Editor | Cinematographer | Photographer | Visual Effects Artist
                    </span>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={handleDownload}
                    className="p-2 rounded bg-zinc-800 text-zinc-200 hover:text-white hover:bg-zinc-700"
                    title="Download"
                  >
                    <FileDown className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => setShowViewer(false)}
                    className="p-2 rounded bg-zinc-800 text-zinc-200 hover:text-white hover:bg-zinc-700"
                  >
                    <X className="w-5 h-5" />
                  </button>
                </div>
              </div>

              {/* Document Body */}
              <div className="relative aspect-[3/4] sm:aspect-[4/3] w-full bg-black flex items-center justify-center overflow-hidden">
                <iframe
                  src={profile.resumeUrl || "https://drive.google.com/file/d/1mJ_d92Ojkk5z0z-htAeRHBubtQ7_YeMJ/preview"}
                  title="Gokulavasan Official Resume PDF"
                  className="w-full h-full border-0"
                  allow="autoplay"
                />
              </div>

              {/* Footer */}
              <div className="p-4 bg-zinc-950 border-t border-zinc-800 flex justify-between items-center">
                <span className="text-xs text-zinc-500 font-mono">VERIFIED OFFICIAL DOSSIER</span>
                <button
                  onClick={handleDownload}
                  className="px-5 py-2 rounded-lg bg-gradient-to-r from-[#B50016] to-[#FF5A00] text-white font-bold text-xs uppercase tracking-wider flex items-center gap-2"
                >
                  <FileDown className="w-4 h-4" />
                  <span>Download PDF</span>
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </section>
  );
};
