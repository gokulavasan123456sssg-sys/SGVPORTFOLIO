import React from 'react';
import { motion } from 'framer-motion';
import { Film, Camera, Video, Sparkles, Award, CheckCircle2, Clapperboard } from 'lucide-react';
import { ProfileData } from '../types';

interface AboutMeProps {
  profile: ProfileData;
}

export const AboutMe: React.FC<AboutMeProps> = ({ profile }) => {
  const highlights = [
    { title: 'Video Editing', desc: 'Pacing, narrative rhythm & dynamic visual cuts', icon: Film },
    { title: 'Photography', desc: 'Portraits, events, composition & retouching', icon: Camera },
    { title: 'Cinematography', desc: 'Camera operation, shot blocking & framing', icon: Video },
    { title: 'Visual Storytelling', desc: 'Emotional depth and cinematic pacing', icon: Clapperboard },
    { title: 'Lighting & Camera Operation', desc: '3-point studio & atmospheric natural light', icon: Camera },
    { title: 'Colour Grading', desc: 'Mood palettes, DaVinci Resolve & LUT workflows', icon: Sparkles },
    { title: 'VFX & Compositing', desc: 'Nuke, Maya, CG integration & roto clean plates', icon: Award },
  ];

  return (
    <section id="about" className="relative py-28 bg-[#050505] text-white overflow-hidden border-t border-zinc-900">
      {/* Cinematic Red & Orange Ambient Lighting */}
      <div className="absolute top-1/4 -left-32 w-96 h-96 bg-[#B50016]/15 rounded-full blur-[130px] pointer-events-none" />
      <div className="absolute bottom-10 -right-32 w-96 h-96 bg-[#FF5A00]/15 rounded-full blur-[130px] pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-20">
          <motion.div
            initial={{ opacity: 0, y: 15 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-zinc-900 border border-red-900/40 text-xs uppercase font-bold tracking-[0.25em] text-[#FF5A00] mb-4"
          >
            <Film className="w-3.5 h-3.5 text-[#FF2020]" />
            <span>02. THE DIRECTOR'S VISION</span>
          </motion.div>

          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.7 }}
            className="font-cinematic text-3xl sm:text-5xl lg:text-6xl font-black uppercase tracking-[0.1em] text-white leading-tight"
          >
            {profile.aboutHeading || "BEHIND THE CAMERA. BEYOND THE FRAME."}
          </motion.h2>

          <motion.p
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            transition={{ delay: 0.3 }}
            className="mt-4 text-sm sm:text-base font-light tracking-widest text-[#FF9B24] uppercase"
          >
            THE CRAFT OF VISUAL IMPACT & HIGH-ENERGY STORYTELLING
          </motion.p>
        </div>

        {/* Content Layout */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-center">
          {/* Portrait & Character Card */}
          <motion.div
            initial={{ opacity: 0, x: -40 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
            className="lg:col-span-5 relative"
          >
            <div className="relative mx-auto max-w-md rounded-2xl overflow-hidden border border-red-900/50 bg-gradient-to-b from-zinc-900 to-black p-2 shadow-glow-red group">
              <div className="relative aspect-[4/5] rounded-xl overflow-hidden">
                <img
                  src={profile.avatarUrl}
                  alt={profile.name}
                  className="w-full h-full object-cover object-center filter contrast-110 saturate-105 group-hover:scale-105 transition-transform duration-700"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black via-transparent to-transparent opacity-85" />

                {/* Direct Badge overlay */}
                <div className="absolute bottom-6 left-6 right-6">
                  <div className="flex items-center justify-between text-xs font-mono text-zinc-300 mb-1">
                    <span className="uppercase text-[#FF9B24] font-bold">CURRENT PRODUCTION</span>
                    <span className="text-zinc-400">1 YEAR DEDICATION</span>
                  </div>
                  <h3 className="text-xl font-black uppercase tracking-wide text-white">
                    KOYAKA YOUTUBE CHANNEL
                  </h3>
                  <p className="text-xs text-zinc-400 mt-1">
                    Leading post-production, camera setups & dynamic color grading.
                  </p>
                </div>
              </div>
            </div>

            {/* Cinematic Film Strip Accent Decoration */}
            <div className="hidden sm:flex justify-between items-center px-4 py-2 mt-4 bg-zinc-950 border border-zinc-800 rounded-lg text-[10px] font-mono text-zinc-400 tracking-wider">
              <span>ROLL: #01-SGV</span>
              <span>SCENE: CREATIVE MASTER</span>
              <span className="text-[#FF2020] font-bold">TAKE: PERFECT CUT</span>
            </div>
          </motion.div>

          {/* Narrative & Highlights */}
          <motion.div
            initial={{ opacity: 0, x: 40 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
            className="lg:col-span-7 flex flex-col gap-6"
          >
            {/* Professional Summary Paragraphs */}
            <div className="space-y-4 text-zinc-300 text-sm sm:text-base leading-relaxed">
              {profile.aboutText.map((p, idx) => (
                <p key={idx} className="font-sans">
                  {p}
                </p>
              ))}
            </div>

            {/* Core Capability Badges Grid */}
            <div className="pt-4 border-t border-zinc-800">
              <h3 className="text-xs uppercase font-bold tracking-[0.2em] text-[#FF9B24] mb-4">
                EXPERTISE & TECHNICAL ARSENAL:
              </h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                {highlights.map((item, idx) => (
                  <div
                    key={idx}
                    className="p-3.5 rounded-lg bg-zinc-900/60 border border-zinc-800 hover:border-[#FF2020]/50 transition-all duration-300 flex items-start gap-3"
                  >
                    <div className="p-2 rounded bg-[#B50016]/20 text-[#FF5A00] mt-0.5">
                      <item.icon className="w-4 h-4" />
                    </div>
                    <div>
                      <h4 className="text-xs font-bold uppercase tracking-wider text-white">
                        {item.title}
                      </h4>
                      <p className="text-[11px] text-zinc-400 mt-0.5">
                        {item.desc}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Experience Spotlight Box */}
            <div className="p-5 rounded-xl bg-gradient-to-r from-red-950/40 via-zinc-900 to-black border border-red-900/60 flex items-center justify-between">
              <div>
                <span className="text-[11px] uppercase tracking-[0.2em] text-[#FF5A00] font-bold block">
                  HIGHLIGHTED PRODUCTION EXPERIENCE
                </span>
                <h4 className="text-lg font-bold text-white mt-1">
                  Koyaka YouTube Channel
                </h4>
                <p className="text-xs text-zinc-400">
                  Full-stack video editor, cinematographer & thumbnail/visual designer.
                </p>
              </div>
              <div className="text-right">
                <span className="text-2xl font-cinematic font-black text-[#FF9B24]">
                  1 YEAR
                </span>
                <span className="block text-[10px] uppercase tracking-wider text-zinc-400">
                  CONTINUOUS WORK
                </span>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
};
