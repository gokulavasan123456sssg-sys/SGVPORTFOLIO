import { ProfileData, Project, SkillCategory, ExperienceItem, EducationItem } from '../types';

export const initialProfile: ProfileData = {
  name: "GOKULAVASAN",
  tagline: "Turning Every Frame Into A Story.",
  titles: [
    "Video Editor",
    "Cinematographer",
    "Photographer",
    "Visual Effects Artist"
  ],
  aboutHeading: "BEHIND THE CAMERA. BEYOND THE FRAME.",
  aboutText: [
    "A passionate and versatile visual storyteller with deep expertise across post-production, on-location cinematography, and high-impact visual effects.",
    "Over 1 year of continuous hands-on experience at Koiyakka YouTube Channel, leading end-to-end video pacing, studio lighting setups, color grading, and comedic & viral narrative timing.",
    "Driven by the raw energy of cinema and technical precision, transforming raw captures into color-harmonized, sound-synchronized master cuts."
  ],
  avatarUrl: "/gokulavasan_profile.jpg",
  heroCharacterUrl: "/hero_character.jpg",
  experienceYears: "1 Year",
  currentWork: "Koyaka YouTube Channel",
  email: "gokulavasan123456sssg@gmail.com",
  phone: "+91 9344084435",
  location: "Chennai, India",
  whatsapp: "https://wa.me/919344084435",
  instagram: "https://instagram.com",
  youtube: "https://youtube.com/@koiyakka",
  linkedin: "https://linkedin.com",
  resumeUrl: "https://drive.google.com/file/d/1mJ_d92Ojkk5z0z-htAeRHBubtQ7_YeMJ/preview",
  resumeFileName: "Gokulavasan_Resume.pdf"
};

export const initialSkills: SkillCategory[] = [
  {
    title: "VIDEO EDITING",
    icon: "Film",
    description: "Dynamic pacing, cinematic cuts, color harmonization and precision audio-video synchronization.",
    skills: [
      "Adobe Premiere Pro",
      "DaVinci Resolve",
      "Adobe After Effects",
      "Colour Grading",
      "Audio Synchronisation"
    ]
  },
  {
    title: "PHOTOGRAPHY",
    icon: "Camera",
    description: "Fine-art portraits, high-energy event captures, product aesthetics, and high-end retouching.",
    skills: [
      "Adobe Lightroom",
      "Adobe Photoshop",
      "Portrait Photography",
      "Event Photography",
      "Product Photography",
      "Photo Retouching"
    ]
  },
  {
    title: "CINEMATOGRAPHY",
    icon: "Video",
    description: "Camera mechanics, anamorphic compositions, dramatic multi-point lighting, and visual direction.",
    skills: [
      "Camera Operation",
      "DSLR / Mirrorless Cameras",
      "Shot Composition",
      "Lighting Setup",
      "Direction",
      "Storyboarding"
    ]
  },
  {
    title: "3D & VFX",
    icon: "Sparkles",
    description: "Industry-grade visual effects, 3D modeling, node-based compositing, and dynamic motion graphics.",
    skills: [
      "Autodesk Maya",
      "Nuke",
      "Compositing",
      "Motion Graphics",
      "Visual Effects"
    ]
  }
];

export const initialExperience: ExperienceItem[] = [
  {
    id: "exp-1",
    role: "Video Editor, Photographer & Cinematographer",
    company: "Koyaka YouTube Channel",
    duration: "1 Year",
    description: [
      "Head of visual content creation, responsible for complete post-production workflows from raw footage ingestion to master release.",
      "Operated professional camera packages and multi-point lighting rigs for on-location and studio comedy/vlog shoots.",
      "Color-graded multi-camera sequences in DaVinci Resolve and crafted high-retention motion titles and thumbnail branding.",
      "Managed audio cleanup, comedic sound design timing, and viral YouTube Shorts optimization."
    ],
    highlights: [
      "High-retention viral YouTube comedy pacing",
      "Studio multi-light setup & camera direction",
      "Thumbnail creation & social visual branding"
    ]
  }
];

export const initialEducation: EducationItem[] = [
  {
    id: "edu-1",
    degree: "B.E. Cyber Security",
    institution: "SRM Valliammai Engineering College",
    score: "74%",
    details: "Strong technical foundation in digital systems, media security, and computational tools."
  },
  {
    id: "edu-2",
    degree: "Diploma in Engineering",
    institution: "Sri Ramakrishna Polytechnic College",
    score: "81%",
    details: "Engineering rigor, problem-solving, and hands-on technical execution."
  },
  {
    id: "edu-3",
    degree: "SSLC",
    institution: "Vetri Vikaas Higher Secondary School",
    details: "Secondary school education with distinction."
  },
  {
    id: "edu-4",
    degree: "VFX & Compositing Professional Certification",
    institution: "VFX Image Institution, Vadapalani, Chennai",
    details: "Comprehensive training in Nuke compositing, rotoscopy, clean plate preparation, match moving, and visual effects integration."
  }
];

// AUTHENTIC PROJECTS LOADED DIRECTLY FROM GOKULAVASAN'S GOOGLE DRIVE
export const initialProjects: Project[] = [
  {
    id: "proj-drive-1",
    title: "Koiyakka Channel: Naveena Vazhipari Alaparaigal",
    category: "Video Editing",
    description: "Ajith & Deepan Comedy (GLV Galatta). Fast-paced comedy editing, sound effect punchlines, split-second cuts, and viral audience retention pacing.",
    thumbnail: "https://lh3.googleusercontent.com/d/1T5aixKuorgdprZo-eC56B0vpUSvK0mLh",
    videoUrl: "https://drive.google.com/file/d/1T5aixKuorgdprZo-eC56B0vpUSvK0mLh/preview",
    date: "2024",
    client: "Koiyakka YouTube Channel",
    role: "Lead Video Editor & Sound Designer",
    featured: true,
    order: 1
  },
  {
    id: "proj-drive-2",
    title: "Royal Wedding Films & Candid Cinema",
    category: "Wedding Films",
    description: "Cinematic wedding film capturing sacred South Indian rituals, bride & groom emotional moments, slow-motion flower showers, and rich warm color grading.",
    thumbnail: "https://lh3.googleusercontent.com/d/1Hd40PdkoocUmznK9GN7Mdzl7IA7pJh2v",
    videoUrl: "https://drive.google.com/file/d/1Hd40PdkoocUmznK9GN7Mdzl7IA7pJh2v/preview",
    date: "2024",
    client: "Wedding Production Client",
    role: "Cinematographer & Colorist",
    featured: true,
    order: 2
  },
  {
    id: "proj-drive-3",
    title: "Cinematography Master Reel",
    category: "Cinematography",
    description: "Atmospheric low-angle camera movements, cinematic rim lights, smooth gimbal tracking shots, and dramatic lighting direction.",
    thumbnail: "https://lh3.googleusercontent.com/d/18waMj-y5GHwpFS_wv3_ZMpWrvsRaDNqT",
    videoUrl: "https://drive.google.com/file/d/18waMj-y5GHwpFS_wv3_ZMpWrvsRaDNqT/preview",
    date: "2024",
    role: "Director of Photography",
    featured: true,
    order: 3
  },
  {
    id: "proj-drive-4",
    title: "Official VFX & Compositing Showreel",
    category: "VFX & Showreels",
    description: "Comprehensive visual effects showcase trained at VFX Image Institution, Vadapalani. Featuring Nuke compositing, rotoscopy, clean plating, and 3D integration.",
    thumbnail: "https://lh3.googleusercontent.com/d/1CY9wlPKBDT6fl6pGnTpCU11W3ExTc9el",
    videoUrl: "https://drive.google.com/file/d/1CY9wlPKBDT6fl6pGnTpCU11W3ExTc9el/preview",
    date: "2024",
    client: "VFX Image Institution Showcase",
    role: "VFX Artist & Compositor",
    featured: true,
    order: 4
  },
  {
    id: "proj-drive-5",
    title: "Autodesk Maya 3D Asset & Animation Reel",
    category: "VFX & Showreels",
    description: "3D scene graph, camera matching, model surfacing, and dynamic lighting simulation executed in Autodesk Maya.",
    thumbnail: "https://lh3.googleusercontent.com/d/15ABeF66_XLrFFq9LnL7QXQIQJP_tf0oD",
    videoUrl: "https://drive.google.com/file/d/15ABeF66_XLrFFq9LnL7QXQIQJP_tf0oD/preview",
    date: "2024",
    role: "3D Generalist",
    featured: false,
    order: 5
  },
  {
    id: "proj-drive-6",
    title: "Koiyakka Shorts: ரூல்ஸ் எங்களுக்கு கிடையாது, இப்படிக்கு Home டீம்",
    category: "Video Editing",
    description: "Ajith & Deepan viral comedy short. Dynamic vertical video editing, comedic sound effects, and fast-paced punchline cuts.",
    thumbnail: "https://lh3.googleusercontent.com/d/1QmQ0uRYX9nSTgRKkaSWh_bH_-_deiT1W",
    videoUrl: "https://drive.google.com/file/d/1QmQ0uRYX9nSTgRKkaSWh_bH_-_deiT1W/preview",
    date: "2024",
    client: "Koiyakka",
    role: "Editor & Sound Designer",
    featured: false,
    order: 6
  },
  {
    id: "proj-drive-7",
    title: "Koiyakka Shorts: நீ வீட்டுக்கு தனியா போறியா..",
    category: "Video Editing",
    description: "High-engagement digital comedy cut designed for maximum social watch-time and repeat retention.",
    thumbnail: "https://lh3.googleusercontent.com/d/1aQkFoklMcN4yYnq_mpwr5xwoeGPgJYhq",
    videoUrl: "https://drive.google.com/file/d/1aQkFoklMcN4yYnq_mpwr5xwoeGPgJYhq/preview",
    date: "2024",
    client: "Koiyakka",
    role: "Video Editor",
    featured: false,
    order: 7
  },
  {
    id: "proj-drive-8",
    title: "AI Creative Sequence & Visual Experiments",
    category: "Creative Projects",
    description: "Exploration of modern generative visual technology combined with cinematic editing pacing and motion graphics.",
    thumbnail: "https://lh3.googleusercontent.com/d/1WuxSjIr-XxiyLU91odiV8rLoyIt4lrnu",
    videoUrl: "https://drive.google.com/file/d/1WuxSjIr-XxiyLU91odiV8rLoyIt4lrnu/preview",
    date: "2024",
    role: "Creative Director & Editor",
    featured: false,
    order: 8
  },
  {
    id: "proj-drive-9",
    title: "Pamban Bridge & South Coast Stills Series",
    category: "Photography",
    description: "Landscape and architectural documentary photography capturing the historic Pamban Bridge, Rameshwaram, and the Dhanushkodi coast.",
    thumbnail: "https://lh3.googleusercontent.com/d/1satVp5qiVEdI2OPBmCnWJieo7BNPMGEO",
    date: "2024",
    role: "Photographer & Colorist",
    featured: true,
    order: 9
  }
];
