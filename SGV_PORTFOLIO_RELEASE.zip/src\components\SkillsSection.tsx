import React from 'react';
import { motion } from 'framer-motion';
import { Film, Camera, Video, Sparkles, CheckCircle2 } from 'lucide-react';
import { SkillCategory } from '../types';

interface SkillsSectionProps {
  skills: SkillCategory[];
}

export const SkillsSection: React.FC<SkillsSectionProps> = ({ skills }) => {
  const getIcon = (iconName: string) => {
    switch (iconName.toLowerCase()) {
      case 'camera':
        return Camera;
      case 'video':
        return Video;
      case 'sparkles':
        return Sparkles;
      default:
        return Film;
    }
  };

  return (
    <section id="skills" className="relative py-28 bg-[#050505] text-white overflow-hidden border-t border-zinc-900">
      {/* Background Lighting Elements */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[700px] h-[500px] bg-gradient-to-r from-[#B50016]/10 via-[#FF5A00]/10 to-transparent blur-[140px] pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        {/* Section Heading */}
        <div className="text-center max-w-3xl mx-auto mb-20">
          <motion.div
            initial={{ opacity: 0, y: 15 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-zinc-900 border border-red-900/40 text-xs uppercase font-bold tracking-[0.25em] text-[#FF5A00] mb-4"
          >
            <Sparkles className="w-3.5 h-3.5 text-[#FF2020]" />
            <span>03. TECHNICAL CAPABILITIES</span>
          </motion.div>

          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.7 }}
            className="font-cinematic text-3xl sm:text-5xl font-black uppercase tracking-[0.1em] text-white"
          >
            MASTERED CRAFT & SOFTWARE
          </motion.h2>

          <motion.p
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            transition={{ delay: 0.3 }}
            className="mt-4 text-sm sm:text-base font-light tracking-widest text-zinc-400 uppercase"
          >
            INDUSTRY-STANDARD CREATIVE PIPELINES WITH UNCOMPROMISING PRECISION
          </motion.p>
        </div>

        {/* Skill Category Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {skills.map((category, idx) => {
            const IconComponent = getIcon(category.icon);

            return (
              <motion.div
                key={category.title}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6, delay: idx * 0.15 }}
                whileHover={{ y: -6 }}
                className="relative group p-6 rounded-2xl bg-gradient-to-b from-zinc-900/80 to-zinc-950 border border-zinc-800/80 hover:border-[#FF2020]/60 transition-all duration-500 shadow-lg hover:shadow-glow-red flex flex-col justify-between"
              >
                {/* Glowing top line */}
                <div className="absolute top-0 left-6 right-6 h-[2px] bg-gradient-to-r from-transparent via-[#FF5A00] to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500" />

                <div>
                  {/* Category Header */}
                  <div className="flex items-center justify-between mb-5">
                    <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-[#B50016]/30 to-[#FF5A00]/20 border border-red-900/50 flex items-center justify-center text-[#FF9B24] group-hover:scale-110 transition-transform duration-300">
                      <IconComponent className="w-6 h-6" />
                    </div>
                    <span className="font-mono text-xs text-zinc-500 uppercase tracking-widest">
                      0{idx + 1}
                    </span>
                  </div>

                  <h3 className="font-cinematic text-lg sm:text-xl font-bold uppercase tracking-wider text-white group-hover:text-[#FF9B24] transition-colors">
                    {category.title}
                  </h3>

                  <p className="text-xs text-zinc-400 mt-2 mb-6 leading-relaxed">
                    {category.description}
                  </p>
                </div>

                {/* Animated Progress-Free Skill Badges */}
                <div className="space-y-2.5 pt-4 border-t border-zinc-900">
                  {category.skills.map((skill, sIdx) => (
                    <motion.div
                      key={skill}
                      initial={{ opacity: 0, x: -10 }}
                      whileInView={{ opacity: 1, x: 0 }}
                      viewport={{ once: true }}
                      transition={{ delay: 0.1 + sIdx * 0.05 }}
                      className="flex items-center justify-between p-2 rounded-lg bg-zinc-900/50 border border-zinc-800/60 group-hover:border-zinc-700/60 transition-colors"
                    >
                      <div className="flex items-center gap-2">
                        <div className="w-1.5 h-1.5 rounded-full bg-[#FF2020]" />
                        <span className="text-xs font-medium text-zinc-200 tracking-wide">
                          {skill}
                        </span>
                      </div>
                      <span className="text-[10px] uppercase font-mono tracking-wider text-[#FF9B24] font-semibold">
                        ACTIVE
                      </span>
                    </motion.div>
                  ))}
                </div>
              </motion.div>
            );
          })}
        </div>
      </div>
    </section>
  );
};
