import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Video, Film, Play } from 'lucide-react';

export const CinematographyShowcase: React.FC = () => {
  const [isPlayingDriveVideo, setIsPlayingDriveVideo] = useState(false);

  const cinematicFrames = [
    {
      title: "Atmospheric Temple Architecture & Low Light",
      shotType: "Cinematic Scope Framing",
      focalLength: "35mm T1.5 Cine Prime",
      aperture: "T/2.0",
      lighting: "Natural Ambient + Warm Tungsten Rim Fill",
      image: "https://lh3.googleusercontent.com/d/18waMj-y5GHwpFS_wv3_ZMpWrvsRaDNqT",
      description: "Direct capture from Gokulavasan's cinematography footage: dramatic architectural depth, golden shadows, and dynamic camera movement."
    },
    {
      title: "Pamban Bridge - Coastal Breeze & Ocean Lines",
      shotType: "Ultra-Wide CinemaScope 2.39:1",
      focalLength: "24mm Anamorphic",
      aperture: "T/2.8",
      lighting: "Direct Coastal Sunlight + Sea Reflection",
      image: "https://lh3.googleusercontent.com/d/1satVp5qiVEdI2OPBmCnWJieo7BNPMGEO",
      description: "Capturing horizontal ocean streaks, high dynamic range waves, and historic engineering silhouette."
    },
    {
      title: "Kanyakumari Confluence - Sunset Horizon",
      shotType: "Medium Close-Up (MCU) & Wide Horizon",
      focalLength: "50mm Prime",
      aperture: "T/1.8",
      lighting: "Golden Hour Low Sun + Atmospheric Haze",
      image: "https://lh3.googleusercontent.com/d/11Zx4SEiI-shpHy1Ws6rO8gFgZ2e4cp98",
      description: "Rich sunset color tones, ocean mist, and emotional golden reflections across three converging seas."
    }
  ];

  const [selectedShot, setSelectedShot] = useState(0);

  return (
    <section id="cinematography" className="relative py-28 bg-[#050505] text-white overflow-hidden border-t border-zinc-900">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <motion.div
            initial={{ opacity: 0, y: 15 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-zinc-900 border border-red-900/40 text-xs uppercase font-bold tracking-[0.25em] text-[#FF5A00] mb-4"
          >
            <Video className="w-3.5 h-3.5 text-[#FF2020]" />
            <span>06. DIRECTOR OF PHOTOGRAPHY</span>
          </motion.div>

          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="font-cinematic text-3xl sm:text-5xl font-black uppercase tracking-[0.1em] text-white"
          >
            CINEMATOGRAPHY & LIGHTING DESIGN
          </motion.h2>

          <motion.p
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            className="mt-4 text-sm sm:text-base font-light tracking-widest text-[#FF9B24] uppercase"
          >
            MASTERING LIGHT, ANAMORPHIC GLASS & INTENTIONAL CAMERA BLOCKING
          </motion.p>
        </div>

        {/* Anamorphic 2.39:1 CinemaScope Frame Viewer */}
        <div className="relative mx-auto max-w-5xl rounded-2xl overflow-hidden border border-red-950/80 bg-black shadow-glow-orange p-2 sm:p-4 mb-12">
          {/* Top Letterbox Bar */}
          <div className="w-full h-6 sm:h-9 bg-black flex items-center justify-between px-3 text-[10px] font-mono text-zinc-500 border-b border-zinc-900">
            <span>RATIO: 2.39:1 ANAMORPHIC</span>
            <div className="flex items-center gap-2">
              <span className="text-[#FF2020] font-bold">GOKULAVASAN DP CUT</span>
              <button
                onClick={() => setIsPlayingDriveVideo(!isPlayingDriveVideo)}
                className="px-2 py-0.5 rounded bg-zinc-900 border border-zinc-700 text-[#FF9B24] hover:text-white flex items-center gap-1"
              >
                <Play className="w-2.5 h-2.5 fill-current" />
                <span>{isPlayingDriveVideo ? 'Show Frame Stills' : 'Play Drive video.mp4'}</span>
              </button>
            </div>
            <span>SHUTTER: 180°</span>
          </div>

          {/* Active Cinema Frame or Video */}
          <div className="relative aspect-[2.39/1] w-full overflow-hidden bg-black">
            {isPlayingDriveVideo ? (
              <iframe
                src="https://drive.google.com/file/d/18waMj-y5GHwpFS_wv3_ZMpWrvsRaDNqT/preview"
                title="Gokulavasan Cinematography Video"
                className="w-full h-full border-0"
                allow="autoplay; fullscreen"
                allowFullScreen
              />
            ) : (
              <>
                <motion.img
                  key={selectedShot}
                  initial={{ opacity: 0, scale: 1.05 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ duration: 0.7 }}
                  src={cinematicFrames[selectedShot].image}
                  alt={cinematicFrames[selectedShot].title}
                  className="w-full h-full object-cover object-center filter contrast-110 saturate-110"
                  onError={(e) => {
                    (e.target as HTMLImageElement).src = '/gokulavasan_profile.jpg';
                  }}
                />

                {/* Lens Viewfinder HUD Overlay */}
                <div className="absolute inset-0 pointer-events-none p-4 sm:p-6 flex flex-col justify-between">
                  <div className="flex justify-between items-center text-[10px] sm:text-xs font-mono text-white/80 bg-black/50 px-3 py-1 rounded backdrop-blur max-w-fit">
                    <span>[FRAME: {selectedShot + 1}/3]</span>
                    <span className="ml-3 text-[#FF5A00]">{cinematicFrames[selectedShot].shotType}</span>
                  </div>

                  {/* Play Button Overlay to Trigger Drive Video */}
                  <div className="absolute inset-0 flex items-center justify-center pointer-events-auto">
                    <button
                      onClick={() => setIsPlayingDriveVideo(true)}
                      className="p-4 rounded-full bg-red-950/80 border border-[#FF9B24] text-white shadow-glow-red hover:scale-110 transition-transform flex items-center gap-2"
                    >
                      <Play className="w-5 h-5 fill-current text-white translate-x-0.5" />
                      <span className="text-xs font-bold font-mono tracking-wider pr-1">PLAY FOOTAGE</span>
                    </button>
                  </div>

                  <div className="flex justify-between items-center text-[10px] sm:text-xs font-mono text-zinc-300 bg-black/60 px-3 py-1.5 rounded backdrop-blur">
                    <span>LENS: {cinematicFrames[selectedShot].focalLength}</span>
                    <span className="text-[#FF9B24] hidden sm:inline">IRIS: {cinematicFrames[selectedShot].aperture}</span>
                    <span>LIGHT: {cinematicFrames[selectedShot].lighting}</span>
                  </div>
                </div>
              </>
            )}
          </div>

          {/* Bottom Letterbox Bar */}
          <div className="w-full h-6 sm:h-9 bg-black flex items-center justify-between px-3 text-[10px] font-mono text-zinc-500 border-t border-zinc-900">
            <span>COLOR SPACE: DCI-P3</span>
            <span>SOURCE: GOOGLE DRIVE CINEMATOGRAPHY</span>
          </div>
        </div>

        {/* Shot Selection Tabs */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 max-w-5xl mx-auto">
          {cinematicFrames.map((shot, idx) => (
            <button
              key={shot.title}
              onClick={() => {
                setSelectedShot(idx);
                setIsPlayingDriveVideo(false);
              }}
              className={`p-4 rounded-xl text-left border transition-all duration-300 ${
                selectedShot === idx && !isPlayingDriveVideo
                  ? 'bg-gradient-to-b from-red-950/60 to-zinc-950 border-[#FF2020] shadow-glow-red'
                  : 'bg-zinc-950 border-zinc-800 text-zinc-400 hover:text-white hover:border-zinc-700'
              }`}
            >
              <div className="flex items-center justify-between text-xs font-mono mb-2">
                <span className="text-[#FF5A00] font-bold">SHOT #0{idx + 1}</span>
                <span className="text-zinc-500">{shot.focalLength}</span>
              </div>
              <h4 className="font-cinematic text-sm font-bold text-white">
                {shot.title}
              </h4>
              <p className="text-xs text-zinc-400 mt-2 line-clamp-2">
                {shot.description}
              </p>
            </button>
          ))}
        </div>
      </div>
    </section>
  );
};
