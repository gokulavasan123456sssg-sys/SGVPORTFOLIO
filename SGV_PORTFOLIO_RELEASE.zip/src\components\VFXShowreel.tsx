import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Sparkles, Layers, Box, Cpu, Award, Play } from 'lucide-react';

export const VFXShowreel: React.FC = () => {
  const [activeVideo, setActiveVideo] = useState<'showreel' | '3d'>('showreel');

  const vfxPasses = [
    { name: "Raw Green Screen Ingest", tool: "Nuke Primatte & Keylight", status: "Plate Prep" },
    { name: "Clean Plate & Wire Removal", tool: "Roto & Paint Multi-frame", status: "Prep Done" },
    { name: "3D Camera Matchmove", tool: "Maya Camera Tracker", status: "Solved" },
    { name: "CGI Assets & Lighting Pass", tool: "Autodesk Maya Arnold", status: "Pass Rendered" },
    { name: "Atmospheric Smoke & Embers", tool: "Particle FX Simulation", status: "Composite" },
    { name: "Final Color Grade & Film Grain", tool: "ACES Color Science", status: "Master Output" },
  ];

  return (
    <section id="vfx" className="relative py-28 bg-[#050505] text-white overflow-hidden border-t border-zinc-900">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <motion.div
            initial={{ opacity: 0, y: 15 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-zinc-900 border border-red-900/40 text-xs uppercase font-bold tracking-[0.25em] text-[#FF5A00] mb-4"
          >
            <Sparkles className="w-3.5 h-3.5 text-[#FF2020]" />
            <span>08. VISUAL EFFECTS & 3D DYNAMICS</span>
          </motion.div>

          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="font-cinematic text-3xl sm:text-5xl font-black uppercase tracking-[0.1em] text-white"
          >
            VFX, 3D & COMPOSITING
          </motion.h2>

          <motion.p
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            className="mt-4 text-sm sm:text-base font-light tracking-widest text-[#FF9B24] uppercase"
          >
            CREATING THE IMPOSSIBLE THROUGH AUTODESK MAYA & FOUNDRY NUKE
          </motion.p>
        </div>

        {/* Highlight Banner with Certification */}
        <div className="mb-14 p-6 sm:p-8 rounded-2xl bg-gradient-to-r from-red-950/60 via-zinc-950 to-black border border-red-900/60 shadow-glow-red flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="flex items-start gap-4">
            <div className="p-3.5 rounded-xl bg-[#B50016]/30 border border-[#FF2020]/50 text-[#FF9B24] shrink-0">
              <Award className="w-8 h-8" />
            </div>
            <div>
              <span className="text-[11px] uppercase font-mono tracking-widest text-[#FF5A00] font-bold">
                CERTIFIED INDUSTRY TRAINING
              </span>
              <h3 className="text-xl sm:text-2xl font-cinematic font-bold text-white mt-1">
                VFX & Compositing Certification
              </h3>
              <p className="text-xs sm:text-sm text-zinc-300 mt-1 max-w-xl">
                Trained at <strong>VFX Image Institution, Vadapalani, Chennai</strong> — the epicentre of South Indian film post-production. Rigorous training in multi-channel EXR compositing, projection mapping, camera projection, and photorealistic integration.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-3 shrink-0">
            <div className="px-4 py-2 rounded-lg bg-zinc-900 border border-zinc-700 text-center">
              <span className="block text-xs uppercase font-mono text-zinc-400">Software</span>
              <span className="text-sm font-bold text-[#FF9B24]">NUKE + MAYA</span>
            </div>
            <div className="px-4 py-2 rounded-lg bg-zinc-900 border border-zinc-700 text-center">
              <span className="block text-xs uppercase font-mono text-zinc-400">Location</span>
              <span className="text-sm font-bold text-white">VADAPALANI</span>
            </div>
          </div>
        </div>

        {/* Embedded Authentic Google Drive VFX Videos */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
          {/* Visual Showcase Card with Direct Player */}
          <div className="lg:col-span-7 relative rounded-2xl overflow-hidden border border-red-950 bg-zinc-950 group">
            {/* Video Selector Tabs */}
            <div className="p-3 bg-zinc-900/80 border-b border-zinc-800 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <button
                  onClick={() => setActiveVideo('showreel')}
                  className={`px-3 py-1.5 rounded-lg text-xs font-bold font-mono uppercase transition-colors ${
                    activeVideo === 'showreel'
                      ? 'bg-gradient-to-r from-[#B50016] to-[#FF5A00] text-white shadow-glow-red'
                      : 'bg-zinc-800 text-zinc-400 hover:text-white'
                  }`}
                >
                  Official SHOW REEL.mp4
                </button>
                <button
                  onClick={() => setActiveVideo('3d')}
                  className={`px-3 py-1.5 rounded-lg text-xs font-bold font-mono uppercase transition-colors ${
                    activeVideo === '3d'
                      ? 'bg-gradient-to-r from-[#B50016] to-[#FF5A00] text-white shadow-glow-red'
                      : 'bg-zinc-800 text-zinc-400 hover:text-white'
                  }`}
                >
                  3D.mp4 Maya Reel
                </button>
              </div>

              <span className="text-[10px] font-mono text-[#FF9B24] uppercase">DRIVE SOURCE</span>
            </div>

            <div className="relative aspect-video w-full overflow-hidden bg-black">
              <iframe
                key={activeVideo}
                src={
                  activeVideo === 'showreel'
                    ? 'https://drive.google.com/file/d/1CY9wlPKBDT6fl6pGnTpCU11W3ExTc9el/preview'
                    : 'https://drive.google.com/file/d/15ABeF66_XLrFFq9LnL7QXQIQJP_tf0oD/preview'
                }
                title="Gokulavasan VFX Video"
                className="w-full h-full border-0"
                allow="autoplay; fullscreen"
                allowFullScreen
              />
            </div>
          </div>

          {/* Node Pipeline Steps */}
          <div className="lg:col-span-5 flex flex-col gap-3">
            <h3 className="text-xs font-mono uppercase tracking-[0.2em] text-[#FF5A00] font-bold mb-2">
              FOUNDRY NUKE COMPOSITING PIPELINE:
            </h3>

            {vfxPasses.map((pass, idx) => (
              <motion.div
                key={pass.name}
                initial={{ opacity: 0, x: 20 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ delay: idx * 0.08 }}
                className="p-3.5 rounded-xl bg-zinc-950 border border-zinc-800/80 hover:border-[#FF5A00]/50 transition-all flex items-center justify-between"
              >
                <div className="flex items-center gap-3">
                  <span className="w-6 h-6 rounded-full bg-red-950/60 border border-[#FF2020]/40 flex items-center justify-center text-[10px] font-mono text-[#FF9B24] font-bold">
                    0{idx + 1}
                  </span>
                  <div>
                    <h5 className="text-xs font-bold text-white tracking-wide">
                      {pass.name}
                    </h5>
                    <span className="text-[10px] text-zinc-400">
                      {pass.tool}
                    </span>
                  </div>
                </div>

                <span className="text-[9px] uppercase font-mono tracking-wider px-2 py-0.5 rounded bg-zinc-900 border border-zinc-800 text-[#FF9B24]">
                  {pass.status}
                </span>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};
