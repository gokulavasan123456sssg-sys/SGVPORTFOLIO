import React from 'react';
import { motion } from 'framer-motion';
import { Briefcase, GraduationCap, Calendar, Award, CheckCircle2 } from 'lucide-react';
import { ExperienceItem, EducationItem } from '../types';

interface ExperienceEducationProps {
  experience: ExperienceItem[];
  education: EducationItem[];
}

export const ExperienceEducation: React.FC<ExperienceEducationProps> = ({ experience, education }) => {
  return (
    <section id="experience" className="relative py-28 bg-[#050505] text-white overflow-hidden border-t border-zinc-900">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-20">
          <motion.div
            initial={{ opacity: 0, y: 15 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-zinc-900 border border-red-900/40 text-xs uppercase font-bold tracking-[0.25em] text-[#FF5A00] mb-4"
          >
            <Briefcase className="w-3.5 h-3.5 text-[#FF2020]" />
            <span>09 & 10. BACKGROUND & CREDENTIALS</span>
          </motion.div>

          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="font-cinematic text-3xl sm:text-5xl font-black uppercase tracking-[0.1em] text-white"
          >
            EXPERIENCE & EDUCATION
          </motion.h2>

          <motion.p
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            className="mt-4 text-sm sm:text-base font-light tracking-widest text-[#FF9B24] uppercase"
          >
            GROUNDED IN TECHNICAL RIGOR, SHAPED BY CREATIVE PRODUCTION
          </motion.p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          {/* Work Experience Column */}
          <div>
            <div className="flex items-center gap-3 mb-8">
              <div className="p-2.5 rounded-xl bg-gradient-to-br from-[#B50016] to-[#FF5A00] text-white shadow-glow-red">
                <Briefcase className="w-5 h-5" />
              </div>
              <div>
                <h3 className="font-cinematic text-xl font-black uppercase tracking-wider text-white">
                  PRODUCTION EXPERIENCE
                </h3>
                <span className="text-xs font-mono text-zinc-400">HANDS-ON COMMERCIAL & DIGITAL MEDIA</span>
              </div>
            </div>

            <div className="space-y-6">
              {experience.map((item, idx) => (
                <motion.div
                  key={item.id}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: idx * 0.15 }}
                  className="p-6 rounded-2xl bg-zinc-950 border border-red-950/80 hover:border-[#FF2020]/60 transition-all duration-300 shadow-xl"
                >
                  <div className="flex flex-wrap items-center justify-between gap-2 mb-2">
                    <span className="px-3 py-1 rounded-full bg-red-950/60 border border-[#FF2020]/40 text-[#FF9B24] text-xs font-mono font-bold">
                      {item.duration}
                    </span>
                    <span className="text-xs font-mono text-zinc-500">
                      FULL PRODUCTION
                    </span>
                  </div>

                  <h4 className="font-cinematic text-lg font-bold text-white mt-2">
                    {item.role}
                  </h4>
                  <div className="text-sm font-semibold text-[#FF5A00] mt-0.5">
                    {item.company}
                  </div>

                  <ul className="mt-4 space-y-2 text-xs text-zinc-300 leading-relaxed">
                    {item.description.map((desc, dIdx) => (
                      <li key={dIdx} className="flex items-start gap-2">
                        <CheckCircle2 className="w-3.5 h-3.5 text-[#FF2020] shrink-0 mt-0.5" />
                        <span>{desc}</span>
                      </li>
                    ))}
                  </ul>

                  {item.highlights && item.highlights.length > 0 && (
                    <div className="mt-4 pt-3 border-t border-zinc-900 flex flex-wrap gap-2">
                      {item.highlights.map((h, hIdx) => (
                        <span key={hIdx} className="text-[10px] font-mono uppercase px-2 py-0.5 rounded bg-zinc-900 border border-zinc-800 text-zinc-400">
                          {h}
                        </span>
                      ))}
                    </div>
                  )}
                </motion.div>
              ))}
            </div>
          </div>

          {/* Education & Certification Column */}
          <div>
            <div className="flex items-center gap-3 mb-8">
              <div className="p-2.5 rounded-xl bg-gradient-to-br from-[#FF5A00] to-[#FF9B24] text-black shadow-glow-orange">
                <GraduationCap className="w-5 h-5 text-white" />
              </div>
              <div>
                <h3 className="font-cinematic text-xl font-black uppercase tracking-wider text-white">
                  ACADEMIC & CERTIFICATION
                </h3>
                <span className="text-xs font-mono text-zinc-400">CYBER SECURITY, ENGINEERING & VFX</span>
              </div>
            </div>

            <div className="space-y-4">
              {education.map((edu, idx) => (
                <motion.div
                  key={edu.id}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: idx * 0.1 }}
                  className="p-5 rounded-xl bg-zinc-950 border border-zinc-800/80 hover:border-[#FF5A00]/50 transition-all"
                >
                  <div className="flex items-center justify-between">
                    <h4 className="font-cinematic text-base font-bold text-white">
                      {edu.degree}
                    </h4>
                    {edu.score && (
                      <span className="text-xs font-mono font-bold px-2 py-0.5 rounded bg-red-950/80 text-[#FF9B24] border border-[#FF2020]/40">
                        {edu.score}
                      </span>
                    )}
                  </div>

                  <div className="text-xs font-semibold text-zinc-300 mt-1">
                    {edu.institution}
                  </div>

                  {edu.details && (
                    <p className="text-xs text-zinc-400 mt-2 leading-relaxed">
                      {edu.details}
                    </p>
                  )}
                </motion.div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
