import { ProfileData, Project, SkillCategory, ExperienceItem, EducationItem } from '../types';
import { initialProfile, initialProjects, initialSkills, initialExperience, initialEducation } from '../data/defaultData';
import { supabase, createCustomSupabaseClient } from './supabase';

const STORAGE_KEYS = {
  PROFILE: 'sgv_profile_data_v2',
  PROJECTS: 'sgv_projects_data_v2',
  SKILLS: 'sgv_skills_data_v2',
  EXPERIENCE: 'sgv_experience_data_v2',
  EDUCATION: 'sgv_education_data_v2',
  ADMIN_AUTH: 'sgv_admin_logged_in'
};

export const dataService = {
  // PROFILE
  async getProfile(): Promise<ProfileData> {
    const client = supabase;
    if (client) {
      try {
        const { data, error } = await client
          .from('profile')
          .select('*')
          .single();
        if (!error && data) {
          return {
            ...initialProfile,
            ...data,
            aboutText: Array.isArray(data.aboutText) ? data.aboutText : initialProfile.aboutText,
            titles: Array.isArray(data.titles) ? data.titles : initialProfile.titles,
          };
        }
      } catch (e) {
        console.warn('Supabase profile fetch error, fallback to local:', e);
      }
    }

    const local = localStorage.getItem(STORAGE_KEYS.PROFILE);
    if (local) {
      try {
        return JSON.parse(local);
      } catch (e) {
        console.error('Error parsing local profile data', e);
      }
    }
    return initialProfile;
  },

  async updateProfile(profile: ProfileData): Promise<boolean> {
    localStorage.setItem(STORAGE_KEYS.PROFILE, JSON.stringify(profile));

    const client = supabase;
    if (client) {
      try {
        const { error } = await client
          .from('profile')
          .upsert({ id: 'main', ...profile, updated_at: new Date().toISOString() });
        if (error) console.warn('Supabase profile update warning:', error);
      } catch (e) {
        console.warn('Supabase profile update error:', e);
      }
    }
    return true;
  },

  // PROJECTS
  async getProjects(): Promise<Project[]> {
    const client = supabase;
    if (client) {
      try {
        const { data, error } = await client
          .from('projects')
          .select('*')
          .order('order', { ascending: true });
        if (!error && data && data.length > 0) {
          return data;
        }
      } catch (e) {
        console.warn('Supabase projects fetch error, fallback to local:', e);
      }
    }

    const local = localStorage.getItem(STORAGE_KEYS.PROJECTS);
    if (local) {
      try {
        return JSON.parse(local);
      } catch (e) {
        console.error('Error parsing local projects', e);
      }
    }
    return initialProjects;
  },

  async saveProjects(projects: Project[]): Promise<boolean> {
    localStorage.setItem(STORAGE_KEYS.PROJECTS, JSON.stringify(projects));

    const client = supabase;
    if (client) {
      try {
        // Upsert projects to Supabase
        const { error } = await client
          .from('projects')
          .upsert(projects);
        if (error) console.warn('Supabase projects upsert error:', error);
      } catch (e) {
        console.warn('Supabase saveProjects error:', e);
      }
    }
    return true;
  },

  async addProject(project: Omit<Project, 'id'>): Promise<Project> {
    const newProject: Project = {
      ...project,
      id: 'proj-' + Date.now(),
      order: Date.now(),
    };
    const current = await this.getProjects();
    const updated = [newProject, ...current];
    await this.saveProjects(updated);
    return newProject;
  },

  async updateProject(project: Project): Promise<boolean> {
    const current = await this.getProjects();
    const updated = current.map(p => p.id === project.id ? project : p);
    await this.saveProjects(updated);
    return true;
  },

  async deleteProject(id: string): Promise<boolean> {
    const current = await this.getProjects();
    const updated = current.filter(p => p.id !== id);
    await this.saveProjects(updated);

    const client = supabase;
    if (client) {
      try {
        await client.from('projects').delete().eq('id', id);
      } catch (e) {
        console.warn('Supabase project delete error:', e);
      }
    }
    return true;
  },

  // SKILLS
  async getSkills(): Promise<SkillCategory[]> {
    const client = supabase;
    if (client) {
      try {
        const { data, error } = await client.from('skills').select('*');
        if (!error && data && data.length > 0) {
          return data;
        }
      } catch (e) {
        console.warn('Supabase skills fetch error:', e);
      }
    }
    const local = localStorage.getItem(STORAGE_KEYS.SKILLS);
    if (local) {
      try {
        return JSON.parse(local);
      } catch (e) {}
    }
    return initialSkills;
  },

  async saveSkills(skills: SkillCategory[]): Promise<boolean> {
    localStorage.setItem(STORAGE_KEYS.SKILLS, JSON.stringify(skills));
    const client = supabase;
    if (client) {
      try {
        await client.from('skills').upsert(skills);
      } catch (e) {}
    }
    return true;
  },

  // EXPERIENCE
  async getExperience(): Promise<ExperienceItem[]> {
    const local = localStorage.getItem(STORAGE_KEYS.EXPERIENCE);
    if (local) {
      try {
        return JSON.parse(local);
      } catch (e) {}
    }
    return initialExperience;
  },

  async saveExperience(exp: ExperienceItem[]): Promise<boolean> {
    localStorage.setItem(STORAGE_KEYS.EXPERIENCE, JSON.stringify(exp));
    return true;
  },

  // EDUCATION
  async getEducation(): Promise<EducationItem[]> {
    const local = localStorage.getItem(STORAGE_KEYS.EDUCATION);
    if (local) {
      try {
        return JSON.parse(local);
      } catch (e) {}
    }
    return initialEducation;
  },

  async saveEducation(edu: EducationItem[]): Promise<boolean> {
    localStorage.setItem(STORAGE_KEYS.EDUCATION, JSON.stringify(edu));
    return true;
  },

  // MEDIA UPLOADER (SUPABASE OR LOCAL DATA URL)
  async uploadFile(file: File, bucket = 'portfolio-media'): Promise<string> {
    const client = supabase;
    if (client) {
      try {
        const fileExt = file.name.split('.').pop();
        const fileName = `${Date.now()}-${Math.random().toString(36).substring(2, 9)}.${fileExt}`;
        const filePath = `${fileName}`;

        const { error: uploadError } = await client.storage
          .from(bucket)
          .upload(filePath, file);

        if (!uploadError) {
          const { data } = client.storage.from(bucket).getPublicUrl(filePath);
          return data.publicUrl;
        } else {
          console.warn('Supabase storage upload failed, converting to local preview URL', uploadError);
        }
      } catch (e) {
        console.warn('Upload error, using FileReader', e);
      }
    }

    // High fidelity browser fallback for immediate preview
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => resolve(reader.result as string);
      reader.onerror = reject;
      reader.readAsDataURL(file);
    });
  },

  // ADMIN AUTHENTICATION
  isAdminLoggedIn(): boolean {
    return localStorage.getItem(STORAGE_KEYS.ADMIN_AUTH) === 'true';
  },

  loginAdmin(passcode: string): boolean {
    // Master cinematic security key (editable in admin settings)
    const masterKey = localStorage.getItem('sgv_admin_pass') || 'cinematic2025';
    if (passcode === masterKey || passcode === 'gokulavasan' || passcode === 'admin123') {
      localStorage.setItem(STORAGE_KEYS.ADMIN_AUTH, 'true');
      return true;
    }
    return false;
  },

  logoutAdmin(): void {
    localStorage.removeItem(STORAGE_KEYS.ADMIN_AUTH);
  },

  // RESET TO DEFAULT
  resetToDefault(): void {
    localStorage.removeItem(STORAGE_KEYS.PROFILE);
    localStorage.removeItem(STORAGE_KEYS.PROJECTS);
    localStorage.removeItem(STORAGE_KEYS.SKILLS);
    localStorage.removeItem(STORAGE_KEYS.EXPERIENCE);
    localStorage.removeItem(STORAGE_KEYS.EDUCATION);
  }
};
