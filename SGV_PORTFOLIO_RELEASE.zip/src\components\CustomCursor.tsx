import React, { useEffect, useState } from 'react';
import { motion } from 'framer-motion';

export const CustomCursor: React.FC = () => {
  const [pos, setPos] = useState({ x: -100, y: -100 });
  const [isHovered, setIsHovered] = useState(false);
  const [isClicking, setIsClicking] = useState(false);
  const [isTouch, setIsTouch] = useState(false);

  useEffect(() => {
    // Check if device has touch
    if (window.matchMedia('(pointer: coarse)').matches) {
      setIsTouch(true);
      return;
    }

    const onMouseMove = (e: MouseEvent) => {
      setPos({ x: e.clientX, y: e.clientY });

      const target = e.target as HTMLElement;
      if (
        target &&
        (target.tagName === 'BUTTON' ||
          target.tagName === 'A' ||
          target.closest('button') ||
          target.closest('a') ||
          target.getAttribute('role') === 'button' ||
          target.classList.contains('cursor-pointer'))
      ) {
        setIsHovered(true);
      } else {
        setIsHovered(false);
      }
    };

    const onMouseDown = () => setIsClicking(true);
    const onMouseUp = () => setIsClicking(false);

    window.addEventListener('mousemove', onMouseMove);
    window.addEventListener('mousedown', onMouseDown);
    window.addEventListener('mouseup', onMouseUp);

    return () => {
      window.removeEventListener('mousemove', onMouseMove);
      window.removeEventListener('mousedown', onMouseDown);
      window.removeEventListener('mouseup', onMouseUp);
    };
  }, []);

  if (isTouch) return null;

  return (
    <div className="pointer-events-none fixed inset-0 z-50 overflow-hidden">
      {/* Central Viewfinder Reticle */}
      <motion.div
        className="fixed top-0 left-0 w-8 h-8 -ml-4 -mt-4 border border-[#FF2020]/70 rounded-full flex items-center justify-center pointer-events-none"
        animate={{
          x: pos.x,
          y: pos.y,
          scale: isClicking ? 0.7 : isHovered ? 1.6 : 1,
          borderColor: isHovered ? '#FF9B24' : '#FF2020',
          backgroundColor: isHovered ? 'rgba(255, 32, 32, 0.12)' : 'transparent',
        }}
        transition={{ type: 'spring', damping: 25, stiffness: 350, mass: 0.2 }}
      >
        {/* Reticle crosshair dots */}
        <div className="w-1.5 h-1.5 bg-[#FF2020] rounded-full shadow-[0_0_8px_#FF2020]" />
      </motion.div>

      {/* Trailing Glow Aura */}
      <motion.div
        className="fixed top-0 left-0 w-24 h-24 -ml-12 -mt-12 rounded-full pointer-events-none"
        style={{
          background: 'radial-gradient(circle, rgba(255,90,0,0.18) 0%, rgba(255,32,32,0.05) 50%, transparent 80%)',
        }}
        animate={{
          x: pos.x,
          y: pos.y,
        }}
        transition={{ type: 'spring', damping: 35, stiffness: 200, mass: 0.5 }}
      />
    </div>
  );
};
