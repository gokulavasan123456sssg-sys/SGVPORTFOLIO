import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Play, Eye, X, Film, Calendar, User, ExternalLink, Video } from 'lucide-react';
import { Project, ProjectCategory } from '../types';
import { cinematicAudio } from '../lib/audioFX';

interface SelectedWorksProps {
  projects: Project[];
}

export const SelectedWorks: React.FC<SelectedWorksProps> = ({ projects }) => {
  const [selectedCategory, setSelectedCategory] = useState<ProjectCategory>('All');
  const [activeProject, setActiveProject] = useState<Project | null>(null);

  const categories: ProjectCategory[] = [
    'All',
    'Wedding Films',
    'Video Editing',
    'Cinematography',
    'Photography',
    'VFX & Showreels',
    'Creative Projects'
  ];

  const filteredProjects = selectedCategory === 'All'
    ? projects
    : projects.filter(p => p.category === selectedCategory);

  const handleOpenProject = (proj: Project) => {
    setActiveProject(proj);
    cinematicAudio.playWhoosh();
  };

  const handleCloseModal = () => {
    setActiveProject(null);
  };

  // Helper to parse video embed
  const renderVideoPlayer = (url?: string) => {
    if (!url) return null;

    // YouTube
    if (url.includes('youtube.com') || url.includes('youtu.be')) {
      let videoId = '';
      if (url.includes('youtu.be/')) {
        videoId = url.split('youtu.be/')[1].split('?')[0];
      } else if (url.includes('v=')) {
        videoId = url.split('v=')[1].split('&')[0];
      }
      return (
        <iframe
          src={`https://www.youtube.com/embed/${videoId}?autoplay=1&rel=0`}
          title="Video Player"
          className="w-full h-full rounded-xl"
          allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
          allowFullScreen
        />
      );
    }

    // Google Drive video preview
    if (url.includes('drive.google.com')) {
      const previewUrl = url.replace('/view', '/preview').replace('?usp=sharing', '');
      return (
        <iframe
          src={previewUrl}
          title="Drive Video"
          className="w-full h-full rounded-xl"
          allow="autoplay"
          allowFullScreen
        />
      );
    }

    // Vimeo
    if (url.includes('vimeo.com')) {
      const vimeoId = url.split('/').pop();
      return (
        <iframe
          src={`https://player.vimeo.com/video/${vimeoId}?autoplay=1`}
          title="Vimeo Player"
          className="w-full h-full rounded-xl"
          allow="autoplay; fullscreen; picture-in-picture"
          allowFullScreen
        />
      );
    }

    // Direct MP4 / WebM
    return (
      <video
        src={url}
        controls
        autoPlay
        className="w-full h-full rounded-xl object-contain bg-black"
      />
    );
  };

  return (
    <section id="projects" className="relative py-28 bg-[#050505] text-white overflow-hidden border-t border-zinc-900">
      {/* Background Accent Gradients */}
      <div className="absolute top-20 right-0 w-[500px] h-[500px] bg-[#FF2020]/10 rounded-full blur-[140px] pointer-events-none" />
      <div className="absolute bottom-20 left-0 w-[500px] h-[500px] bg-[#FF5A00]/10 rounded-full blur-[140px] pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        {/* Section Heading */}
        <div className="text-center max-w-3xl mx-auto mb-14">
          <motion.div
            initial={{ opacity: 0, y: 15 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-zinc-900 border border-red-900/40 text-xs uppercase font-bold tracking-[0.25em] text-[#FF5A00] mb-4"
          >
            <Film className="w-3.5 h-3.5 text-[#FF2020]" />
            <span>04. PORTFOLIO SHOWCASE</span>
          </motion.div>

          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="font-cinematic text-3xl sm:text-5xl lg:text-6xl font-black uppercase tracking-[0.1em] text-white"
          >
            SELECTED CINEMATIC WORKS
          </motion.h2>

          <motion.p
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            className="mt-4 text-sm sm:text-base font-light tracking-widest text-[#FF9B24] uppercase"
          >
            CRAFTED WITH PRECISION, PASSION & MASS CINEMA INTENSITY
          </motion.p>
        </div>

        {/* Category Filter Pills */}
        <div className="flex flex-wrap items-center justify-center gap-2.5 mb-14">
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => {
                setSelectedCategory(cat);
                cinematicAudio.playWhoosh();
              }}
              className={`px-4 sm:px-5 py-2 rounded-full text-xs uppercase font-bold tracking-wider transition-all duration-300 ${
                selectedCategory === cat
                  ? 'bg-gradient-to-r from-[#B50016] to-[#FF5A00] text-white shadow-glow-red scale-105'
                  : 'bg-zinc-900/80 border border-zinc-800 text-zinc-400 hover:text-white hover:border-zinc-700'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        {/* Projects Grid */}
        <motion.div
          layout
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8"
        >
          <AnimatePresence>
            {filteredProjects.map((project) => (
              <motion.div
                key={project.id}
                layout
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.95 }}
                transition={{ duration: 0.4 }}
                className="group relative rounded-2xl overflow-hidden bg-zinc-950 border border-zinc-800/80 hover:border-[#FF2020]/70 transition-all duration-500 shadow-xl flex flex-col justify-between"
              >
                {/* Thumbnail Container */}
                <div
                  className="relative aspect-video w-full overflow-hidden cursor-pointer"
                  onClick={() => handleOpenProject(project)}
                >
                  <img
                    src={project.thumbnail}
                    alt={project.title}
                    className="w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-700 filter brightness-95 group-hover:brightness-105"
                  />

                  {/* Gradient Shadow Overlay */}
                  <div className="absolute inset-0 bg-gradient-to-t from-black via-black/30 to-transparent opacity-70 group-hover:opacity-40 transition-opacity" />

                  {/* Play / View Button Overlay */}
                  <div className="absolute inset-0 flex items-center justify-center">
                    <div className="w-14 h-14 rounded-full bg-[#B50016]/90 border border-[#FF9B24] flex items-center justify-center text-white shadow-glow-red transform scale-90 opacity-80 group-hover:scale-110 group-hover:opacity-100 transition-all duration-300">
                      {project.videoUrl ? (
                        <Play className="w-6 h-6 fill-current translate-x-0.5 text-white" />
                      ) : (
                        <Eye className="w-6 h-6 text-white" />
                      )}
                    </div>
                  </div>

                  {/* Category Pill on Thumbnail */}
                  <div className="absolute top-3 left-3 bg-black/80 backdrop-blur-md border border-[#FF2020]/50 text-[#FF9B24] text-[10px] uppercase font-bold tracking-widest px-2.5 py-1 rounded">
                    {project.category}
                  </div>

                  {project.date && (
                    <div className="absolute top-3 right-3 bg-black/80 backdrop-blur-md text-zinc-400 text-[10px] font-mono px-2 py-1 rounded">
                      {project.date}
                    </div>
                  )}
                </div>

                {/* Project Info */}
                <div className="p-6 flex flex-col justify-between flex-grow">
                  <div>
                    <h3 className="font-cinematic text-lg font-bold text-white group-hover:text-[#FF9B24] transition-colors leading-snug">
                      {project.title}
                    </h3>
                    <p className="text-xs text-zinc-400 mt-2 line-clamp-2 leading-relaxed">
                      {project.description}
                    </p>
                  </div>

                  <div className="mt-5 pt-4 border-t border-zinc-900 flex items-center justify-between text-xs">
                    {project.role && (
                      <span className="text-zinc-500 font-medium">
                        Role: <span className="text-zinc-300 font-semibold">{project.role}</span>
                      </span>
                    )}
                    <button
                      onClick={() => handleOpenProject(project)}
                      className="text-[#FF5A00] hover:text-[#FF9B24] font-bold text-xs uppercase tracking-wider flex items-center gap-1 group-hover:translate-x-1 transition-transform ml-auto"
                    >
                      <span>VIEW PROJECT</span>
                      <ExternalLink className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              </motion.div>
            ))}
          </AnimatePresence>
        </motion.div>
      </div>

      {/* FULL-SCREEN VIDEO / PROJECT MODAL */}
      <AnimatePresence>
        {activeProject && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 bg-black/95 backdrop-blur-xl flex items-center justify-center p-4 sm:p-6 lg:p-10"
            onClick={handleCloseModal}
          >
            <motion.div
              initial={{ scale: 0.9, y: 20 }}
              animate={{ scale: 1, y: 0 }}
              exit={{ scale: 0.9, y: 20 }}
              transition={{ duration: 0.3 }}
              className="relative w-full max-w-5xl bg-zinc-950 border border-zinc-800 rounded-2xl overflow-hidden shadow-2xl flex flex-col max-h-[90vh]"
              onClick={(e) => e.stopPropagation()}
            >
              {/* Modal Header */}
              <div className="p-4 sm:p-5 border-b border-zinc-800 flex items-center justify-between bg-zinc-900/60">
                <div className="flex items-center gap-3">
                  <span className="px-2.5 py-0.5 rounded bg-[#B50016]/30 border border-[#FF2020]/40 text-[#FF9B24] text-[10px] uppercase font-bold tracking-widest">
                    {activeProject.category}
                  </span>
                  <h3 className="font-cinematic text-lg sm:text-xl font-bold text-white tracking-wide truncate max-w-md">
                    {activeProject.title}
                  </h3>
                </div>
                <button
                  onClick={handleCloseModal}
                  className="p-2 rounded-full bg-zinc-800 text-zinc-400 hover:text-white hover:bg-zinc-700 transition-colors"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              {/* Modal Body: Player or Image View */}
              <div className="relative aspect-video w-full bg-black flex items-center justify-center">
                {activeProject.videoUrl ? (
                  renderVideoPlayer(activeProject.videoUrl)
                ) : (
                  <img
                    src={activeProject.thumbnail}
                    alt={activeProject.title}
                    className="w-full h-full object-contain"
                  />
                )}
              </div>

              {/* Modal Footer: Project Breakdown */}
              <div className="p-5 sm:p-6 bg-zinc-950 flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-t border-zinc-900 overflow-y-auto">
                <div className="max-w-2xl">
                  <p className="text-sm text-zinc-300 leading-relaxed">
                    {activeProject.description}
                  </p>
                  <div className="flex flex-wrap items-center gap-4 mt-3 text-xs text-zinc-400">
                    {activeProject.client && (
                      <span>Client: <strong className="text-white">{activeProject.client}</strong></span>
                    )}
                    {activeProject.role && (
                      <span>Role: <strong className="text-white">{activeProject.role}</strong></span>
                    )}
                    {activeProject.date && (
                      <span>Release: <strong className="text-white">{activeProject.date}</strong></span>
                    )}
                  </div>
                </div>

                {activeProject.videoUrl && (
                  <a
                    href={activeProject.videoUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center justify-center gap-2 px-5 py-2.5 rounded-lg bg-gradient-to-r from-[#B50016] to-[#FF5A00] text-white font-bold text-xs uppercase tracking-wider hover:brightness-110 transition-all shrink-0 shadow-glow-red"
                  >
                    <Video className="w-4 h-4" />
                    <span>Watch in Full HD</span>
                  </a>
                )}
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </section>
  );
};
